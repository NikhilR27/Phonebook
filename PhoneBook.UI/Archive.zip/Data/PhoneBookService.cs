﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using PhoneBook.Domain;

namespace PhoneBook.UI.Data
{
    public class PhoneBookApiService
    {
        private readonly IHttpClientFactory _clientFactory;

        public PhoneBookApiService(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async Task<List<Phonebook>> GetPhonebooksAsync()
        {
            var result = new List<Phonebook>();

            var url = "/api/phonebook/phonebook";

            var request = new HttpRequestMessage(HttpMethod.Get, url);

            try
            {
                using (var client = _clientFactory.CreateClient("PhoneBookServiceApi"))
                {
                    var response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var stringResponse = await response.Content.ReadAsStringAsync();

                        result = JsonSerializer.Deserialize<List<Phonebook>>(stringResponse,
                            new JsonSerializerOptions() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
                    }
                    else
                    {
                        result = Array.Empty<Phonebook>().ToList();
                    }

                    return result;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return Array.Empty<Phonebook>().ToList();
            }
                
        }
    }
}
